import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Random;
import java.util.Scanner;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {

	Scanner scan = new Scanner(System.in);
	Random rand = new Random();
	Date date = new Date();
	
	Pattern pattern;
	Matcher matcher;
	
	Vector<Pulsa> pulsa = new Vector<>();
	Vector<Barang> barang = new Vector<>();
	
	Pulsa p;
	Barang b;
	int count = 0;
	
	String namaPembeli="";
	String namaItem="";
	Integer hargaItem=0;
	String tanggalTransaksi="";
	String kodeTransaksi="";
	String nomorHape="";
	Integer saldo=0;
	Integer quantity=0;
	String alamat="";
	String email="";
	String pass="";
	
	private void welcome(){
		System.out.println("||=================================================================================================================||");
		System.out.println("||=================================================================================================================||");
		System.out.println("||||||||||||*****     ***** *******  **        *******    ******      ** **      *******      *   *   *  ||||||||||||");
		System.out.println("|||||||||||| ***       ***  ***     ****      *****  **  ********    *******     ***         *** *** *** ||||||||||||");
		System.out.println("||||||||||||  **   *   **   ******  ****      *****     ***    ***  ** *** **    ******      *** *** *** ||||||||||||");
		System.out.println("||||||||||||   ** *** **    ******  ***       *****     ***    *** **   *   **   ******       *   *   *  ||||||||||||");
		System.out.println("||||||||||||    *******     ***     ********* *****  **  ******** ***       ***  ***                     ||||||||||||");
		System.out.println("||||||||||||     ** **      *******  *******   *******    ****** *****     ***** *******      O   O   O  ||||||||||||");
		System.out.println("||=================================================================================================================||");
		System.out.println("||=================================================================================================================||");
		System.out.println("||                              1. Bukapedia Mall Adalah Toko Online Yang Unik.                                    ||");
		System.out.println("||                        2. Anda Bisa Mendapatkan Pengalaman Yang Sangat Menyenangkan.                            ||");
		System.out.println("||                    3. Dalam Berbelanja, Kami Harapkan Agar Sesuai Dengan Prosedur Yang Ada.                     ||");
		System.out.println("||=================================================================================================================||");
		System.out.println("||                                              SELAMAT BERBELANJA !                                               ||");
		System.out.println("||=================================================================================================================||");
		System.out.println("||=================================================================================================================||");
		System.out.println("");
		System.out.println("");
		System.out.print("Press Enter to Continue...");
		scan.nextLine();
		enter();
		
	}
	
	private boolean provider(String namaItem){
		if(!namaItem.equals("TELKOMSEL")&&!namaItem.equals("INDOSAT")&&!namaItem.equals("TRI")&&!namaItem.equals("XL")&&!namaItem.equals("AXIS")&&!namaItem.equals("SMARTFREN"))
			return true;
		return false;
	}
	
	private boolean nope(String nomorHape){
		if(!nomorHape.matches("[0-9]*") || (nomorHape.length()<10||nomorHape.length()>12)|| !nomorHape.startsWith("08"))
			return true;
		return false;
	}
	
	private boolean saldo1(int saldo){
		if(saldo!=10000 && saldo!=15000 && saldo!=20000&& saldo!=25000 && saldo!=30000 && saldo!=35000 && saldo!=40000 && saldo!=45000 && saldo!=50000
			&& saldo!=55000 && saldo!=60000 && saldo!=65000 && saldo!=70000 && saldo!=75000 && saldo!=80000 && saldo!=85000 && saldo!=90000 && saldo!=95000 && saldo!=100000)
				return true;
		return false;
	}
	
	private boolean pembeli(String email){
		if(email.length()<11||!email.contains("@gmail")||!email.endsWith(".com"))
			return true;
		return false;
	}
	
	private boolean passPembeli(String pass){
		if(!Pattern.matches("[a-z][A-Z]{1,2}[0-9]{1,5}$", pass))
				return true;
		return false;
	}
	
	private void inputData(){
		do{
			enter();
			template();
			System.out.println("==========================================================================");
			System.out.print("Please Input Your Name [ 3 - 20 Characters ] : ");
			namaPembeli=scan.nextLine();
			
			if(namaPembeli.length()<3||namaPembeli.length()>20){
				enter();
				template();
				System.out.println("==========================================================================");
				System.out.println("Mohon Untuk Memasukkan Nama Dengan Karakter Antara 3 Sampai 20 !");
				System.out.println("==========================================================================");
				System.out.println("Press Enter To Continue...");
				scan.nextLine();
			}
		}while(namaPembeli.length()<3||namaPembeli.length()>20);
		System.out.println("==========================================================================");
		System.out.println("Press enter to continue..");
		scan.nextLine();
		enter();
		
		int flag = 0;
		do{
			enter();
			template();
			System.out.println("==========================================================================");
			System.out.print("Please Input Your Email [ ...@gmail.com ] : ");
			email=scan.nextLine();
			flag++;
			if(pembeli(email)&&flag!=3){
				enter();
				template();
				System.out.println("==========================================================================");
				System.out.println("Mohon Untuk Memasukkan Email Anda Dengan Benar !");
				System.out.println("==========================================================================");
				System.out.println("Press Enter To Continue...");
				scan.nextLine();
			}
			if(flag==3){
				enter();
				System.out.println("==========================================================================");
				System.out.println("Mohon Untuk Menunggu Beberapa saat !");
				System.out.println("==========================================================================");
				Run run = new Run();
				Thread tr = new Thread(run);
				tr.start();
				flag=0;
				scan.nextLine();
				enter();
				System.out.println("==========================================================================");
				System.out.println("Re-enter Email !!");
				System.out.println("==========================================================================");
				System.out.println("");
				System.out.println("Press enter to continue..");
				scan.nextLine();
			}
		}while(pembeli(email));
		System.out.println("==========================================================================");
		System.out.println("Press enter to continue..");
		scan.nextLine();
		enter();
		
		int flag1 = 0;
		do{
			enter();
			template();
			System.out.println("==============================================================================================");
			System.out.print("Please Input Your Password [ Start with 1 Lowercase + 2 Uppercase + 5 number ] : ");
			pass=scan.nextLine();
			flag1++;
			if(passPembeli(pass)&&flag1!=3){
				enter();
				template();
				System.out.println("==========================================================================");
				System.out.println("Mohon Untuk Memasukkan Password Anda Sesuai Syarat !");
				System.out.println("==========================================================================");
				System.out.println("Press Enter To Continue...");
				scan.nextLine();
			}
			if(flag1==3){
				enter();
				System.out.println("==========================================================================");
				System.out.println("Mohon Untuk Menunggu Beberapa saat !");
				System.out.println("==========================================================================");
				Run run = new Run();
				Thread tr = new Thread(run);
				tr.start();
				flag1=0;
				scan.nextLine();
				enter();
				System.out.println("==========================================================================");
				System.out.println("Re-enter Password !!");
				System.out.println("==========================================================================");
				System.out.println("");
				System.out.println("Press enter to continue..");
				scan.nextLine();
			}
		}while(passPembeli(pass));
		System.out.println("==============================================================================================");
		System.out.println("Press enter to continue..");
		scan.nextLine();
		enter();
	}
	
	
	private void inputPulsa(){
		do{
			enter();
			template();
			System.out.println("=============================");
			System.out.println("|           STEP 1          |");
			System.out.println("=============================");
			System.out.println("|  Operator Yang Tersedia:  |");
			System.out.println("=============================");
			System.out.println("|| 1. TELKOMSEL            ||");
			System.out.println("|| 2. INDOSAT              ||");
			System.out.println("|| 3. TRI                  ||");
			System.out.println("|| 4. XL                   ||");
			System.out.println("|| 5. AXIS                 ||");
			System.out.println("|| 6. SMARTFREN            ||");
			System.out.println("=============================");
			
			System.out.print("Silahkan Ketik Operator Kartu Anda ( Mohon Diketik Sesuai ! ) : ");
			namaItem=scan.nextLine();
			
			if(provider(namaItem)){
				enter();
				template();
				System.out.println("==========================================================================");
				System.out.println("Mohon Untuk Memasukkan Nama Operator Sesuai Dengan Yang Tertera");
				System.out.println("==========================================================================");
				System.out.println("Press Enter To Continue...");
				scan.nextLine();
			}
			
		}while(provider(namaItem));
		
		do{
			enter();
			template();
			System.out.println("======================================================");
			System.out.println("|                       STEP 2                       |");
			System.out.println("======================================================");
			System.out.print("Input Nomor HP [ 10 - 12 Angka] (08..) : ");
		    nomorHape = scan.nextLine();
		    
		    if(nope(nomorHape)){
				enter();
				template();
				System.out.println("================================================================================");
				System.out.println("Mohon Untuk Memasukkan Nomor HP Dengan Diawali 08.. antara 10 sampa 12 angka !");
				System.out.println("================================================================================");
				System.out.println("Press Enter To Continue...");
				scan.nextLine();
			}
		    
		}while(nope(nomorHape));	

		
		do{
			enter();
			template();
			System.out.println("======================================================================");
			System.out.println("|                                 STEP 3                             |");
			System.out.println("======================================================================");
			System.out.print("Saldo Pulsa [ 10000 - 100000 ] ( Kelipatan 5000 ): ");
			
			try{
				saldo=scan.nextInt(); 
				scan.nextLine();
			}catch(Exception e){
				saldo=-1;
				scan.nextLine();
			}
			
			if(saldo1(saldo)){
				enter();
				template();
				System.out.println("===============================================================================");
				System.out.println("Mohon Masukkan Saldo Pulsa Antara 10000 Sampai 100000 Dengan Kelipatan 5000 ! ");
				System.out.println("===============================================================================");
				System.out.println("Press Enter To Continue...");
				scan.nextLine();
				enter();
			}
			
		}while(saldo1(saldo));
		
		tanggalTransaksi = String.format("%2$tB %2$td, %2$tY", "", date);
		
		char az= (char)(rand.nextInt(26)+'A');
		char az1= (char)(rand.nextInt(26)+'A');
		char az2= (char)(rand.nextInt(26)+'A');
		char az3= (char)(rand.nextInt(26)+'A');
		char az4= (char)(rand.nextInt(26)+'A');
		kodeTransaksi = ""+ az + az1 + az2 + az3 +az4;

		p = new Pulsa(namaPembeli, namaItem, hargaItem, tanggalTransaksi, kodeTransaksi, nomorHape, saldo);
		pulsa.add(p);
		System.out.println("Harga Yang Harus Dibayarkan : "+p.listHarga());
		System.out.println("======================================================================");
		p.setHargaItem(p.listHarga());
		System.out.println("Press Enter To Continue...");
		scan.nextLine();	
	}
	
	private void inputBarang(){
		do {
			enter();
			template();
			System.out.println("======================================================================");
			System.out.println("|                                 STEP 1                             |");
			System.out.println("======================================================================");
			System.out.print("Silahkan Ketik Nama Barang Yang Diinginkan [ 5 - 20 ] : ");
			namaItem = scan.nextLine();
			
			if(namaItem.length()<5 || namaItem.length()>20){
				enter();
				template();
				System.out.println("======================================================================================");
				System.out.println("Mohon Untuk Memasukkan Nama Barang Apa Saja Dengan Jumlah Huruf Antara 5 Sampai 20 !");
				System.out.println("======================================================================================");
				System.out.println("Press Enter To Continue...");
				scan.nextLine();
			}
		}while(namaItem.length()<5 || namaItem.length()>20);
			
		do {
			enter();
			template();
			System.out.println("======================================================================");
			System.out.println("|                                 STEP 2                             |");
			System.out.println("======================================================================");
			System.out.print("Silahkan Ketik Quantity Barang Yang Diinginkan [ 1 - 20 ] : ");
			try{
				quantity = scan.nextInt();
				scan.nextLine();
			}catch(Exception e){
				quantity=-1;
				scan.nextLine();
			}
			
			if(quantity<1 || quantity>20){
				enter();
				template();
				System.out.println("===============================================================================");
				System.out.println("Mohon Masukkan Quantitiy Barang Antara 1 Sampai 20 ! ");
				System.out.println("===============================================================================");
				System.out.println("Press Enter To Continue...");
				scan.nextLine();
				enter();
			}
			
		}while(quantity<1 || quantity>20);
			
			
		hargaItem = Math.abs(rand.nextInt(100000));
		hargaItem+=1;
			
		char huruf1 = (char) (rand.nextInt(26)+'A');
		char huruf2 = (char) (rand.nextInt(26)+'A');
		char huruf3 = (char) (rand.nextInt(26)+'A');
		char huruf4 = (char) (rand.nextInt(26)+'A');
		char huruf5 = (char) (rand.nextInt(26)+'A');
			
		kodeTransaksi =  ""+ huruf1 + huruf2 + huruf3 + huruf4 + huruf5;
		tanggalTransaksi = String.format("%2$tB %2$td, %2$tY", "", date);
		System.out.println("======================================================================");	
		System.out.println("Harga Yang Harus Dibayar : "+hargaItem);
		System.out.println("======================================================================");
		System.out.println("Press Enter To Continue...");
		scan.nextLine();
		b = new Barang(namaPembeli, namaItem, hargaItem, tanggalTransaksi, kodeTransaksi, quantity, alamat);
		barang.add(b);

	}
	
	private void sortHargaPulsa(){
		Collections.sort(pulsa, new Comparator<Pulsa>() {

			public int compare(Pulsa o1, Pulsa o2) {
				return o1.getHargaItem().compareTo(o2.getHargaItem());
			}
			
		});
		
		if(pulsa.isEmpty()){
			template3();
			System.out.println("=============================================================");
			System.out.println("|| NO || Nama Operator |     Nomor HP    |   Total Harga   ||");
			System.out.println("=============================================================");
			System.out.println("|| -  ||       -       |        -        |         -       ||");
			System.out.println("=============================================================");
			System.out.println("");
			System.out.println("\t||==============================================||");
			System.out.println("\t||*************||TIDAK ADA DATA||***************||");
			System.out.println("\t||**************||TERIMA KASIH||****************||");
			System.out.println("\t||*********||Press enter to continue||**********||");
			System.out.println("\t||==============================================||");
		}else{
			template3();
			System.out.println("=============================================================");
			System.out.println("|| NO || Nama Operator |     Nomor HP    |   Total Harga   ||");
			System.out.println("=============================================================");
			for(int i=0;i<pulsa.size();i++){
				System.out.printf("|| %2d || %13s | %15s | %15d ||\n", i+1,pulsa.get(i).getNamaItem(),pulsa.get(i).getNomorHape(),pulsa.get(i).getHargaItem());
				System.out.println("=============================================================");
			}
			System.out.println("");
			System.out.println("Press enter to continue..");
		}
		scan.nextLine();
		enter();
	}
	
	private void sortHargaBarang(){
		Collections.sort(barang, new Comparator<Barang>() {

			public int compare(Barang o1, Barang o2) {
				return o1.getHargaItem().compareTo(o2.getHargaItem());
			}
			
		});
		if(barang.isEmpty()){
			template3();
			System.out.println("====================================================================");
			System.out.println("|| NO ||     Nama Barang      |     Quantity    |   Total Harga   ||");
			System.out.println("====================================================================");
			System.out.println("|| -  ||          -           |        -        |         -       ||");
			System.out.println("====================================================================");
			System.out.println("");
			System.out.println("\t||==============================================||");
			System.out.println("\t||*************||TIDAK ADA DATA||***************||");
			System.out.println("\t||**************||TERIMA KASIH||****************||");
			System.out.println("\t||*********||Press enter to continue||**********||");
			System.out.println("\t||==============================================||");
		}else{
			template3();
			System.out.println("====================================================================");
			System.out.println("|| NO ||     Nama Barang      |     Quantity    |   Total Harga   ||");
			System.out.println("====================================================================");
			for(int i=0;i<barang.size();i++){
				System.out.printf("|| %2d || %20s | %15s | %15d ||\n", i+1,barang.get(i).getNamaItem(),barang.get(i).getQuantity(),barang.get(i).getHargaItem());
				System.out.println("====================================================================");
			}
			System.out.println("");
			System.out.println("Press enter to continue..");
		}
		scan.nextLine();
		enter();
	}
	
	private void sortOperatorPulsa(){
		Collections.sort(pulsa, new Comparator<Pulsa>() {

			public int compare(Pulsa o1, Pulsa o2) {
				return o1.getNamaItem().compareTo(o2.getNamaItem());
			}
			
		});
		if(pulsa.isEmpty()){
			template3();
			System.out.println("=============================================================");
			System.out.println("|| NO || Nama Operator |     Nomor HP    |   Total Harga   ||");
			System.out.println("=============================================================");
			System.out.println("|| -  ||       -       |        -        |         -       ||");
			System.out.println("=============================================================");
			System.out.println("");
			System.out.println("\t||==============================================||");
			System.out.println("\t||*************||TIDAK ADA DATA||***************||");
			System.out.println("\t||**************||TERIMA KASIH||****************||");
			System.out.println("\t||*********||Press enter to continue||**********||");
			System.out.println("\t||==============================================||");
		}else{
			template3();
			System.out.println("=============================================================");
			System.out.println("|| NO || Nama Operator |     Nomor HP    |   Total Harga   ||");
			System.out.println("=============================================================");
			for(int i=0;i<pulsa.size();i++){
				System.out.printf("|| %2d || %13s | %15s | %15d ||\n", i+1,pulsa.get(i).getNamaItem(),pulsa.get(i).getNomorHape(),pulsa.get(i).getHargaItem());
				System.out.println("=============================================================");
			}
			System.out.println("");
			System.out.println("Press enter to continue..");
		}
		scan.nextLine();
		enter();
	}
	
	private void sortNamaBarang(){
		Collections.sort(barang, new Comparator<Barang>() {

			public int compare(Barang o1, Barang o2) {
				return o1.getNamaItem().compareTo(o2.getNamaItem());
			}
			
		});
		if(barang.isEmpty()){
			template3();
			System.out.println("====================================================================");
			System.out.println("|| NO ||     Nama Barang      |     Quantity    |   Total Harga   ||");
			System.out.println("====================================================================");
			System.out.println("|| -  ||          -           |        -        |         -       ||");
			System.out.println("====================================================================");
			System.out.println("");
			System.out.println("\t||==============================================||");
			System.out.println("\t||*************||TIDAK ADA DATA||***************||");
			System.out.println("\t||**************||TERIMA KASIH||****************||");
			System.out.println("\t||*********||Press enter to continue||**********||");
			System.out.println("\t||==============================================||");
		}else{
			template3();
			System.out.println("====================================================================");
			System.out.println("|| NO ||     Nama Barang      |     Quantity    |   Total Harga   ||");
			System.out.println("====================================================================");
			for(int i=0;i<barang.size();i++){
				System.out.printf("|| %2d || %20s | %15s | %15d ||\n", i+1,barang.get(i).getNamaItem(),barang.get(i).getQuantity(),barang.get(i).getHargaItem());
				System.out.println("====================================================================");
			}
			System.out.println("");
			System.out.println("Press enter to continue..");
		}
		scan.nextLine();
		enter();
	}
	
	private void template(){
		System.out.println("\t\t\t================================");
		System.out.println("\t\t\t||^^^^^^^**BUKAPEDIA**^^^^^^^^||");
		System.out.println("\t\t\t||^^^^^^^^****MALL****^^^^^^^^||");
		System.out.println("\t\t\t================================");
		System.out.println("");
		System.out.println("");
	}
	
	private void template1(){
		System.out.println("\t\t\t\t\t================================");
		System.out.println("\t\t\t\t\t||^^^^^^^**BUKAPEDIA**^^^^^^^^||");
		System.out.println("\t\t\t\t\t||^^^^^^^^****MALL****^^^^^^^^||");
		System.out.println("\t\t\t\t\t================================");
		System.out.println("");
		System.out.println("");
	}
	
	private void template3(){
		System.out.println("\t\t================================");
		System.out.println("\t\t||^^^^^^^**BUKAPEDIA**^^^^^^^^||");
		System.out.println("\t\t||^^^^^^^^****MALL****^^^^^^^^||");
		System.out.println("\t\t================================");
		System.out.println("");
		System.out.println("");
	}
	
	private void table(){
		template1();
		System.out.println("=========================================================================================================================");
		System.out.println("|| NO ||    Kode    |        Tanggal         |        Nama        |        Nomor       |     Saldo    |      Total     ||");
		System.out.println("||====||  Transaksi |       Transaksi        |      Operator      |      Handphone     |     Pulsa    |      Harga     ||");
		System.out.println("=========================================================================================================================");
	}
	
	private void table1(){
		template1();
		System.out.println("=======================================================================================================================");
		System.out.println("|| NO ||    Kode    |        Tanggal         |         Nama         |    Quantity    |     Harga    |      Total     ||");
		System.out.println("||====||  Transaksi |       Transaksi        |        Barang        |     Barang     |     Item     |      Harga     ||");
		System.out.println("=======================================================================================================================");
	}
	
	private void checkoutPulsa(){
		enter();
		table();
		if(pulsa.isEmpty()){
			System.out.println("|| -  ||     -      |           -            |          -         |          -         |       -      |        -       ||");
			System.out.println("=========================================================================================================================");
			System.out.println("");
			System.out.println("\t\t\t\t||==============================================||");
			System.out.println("\t\t\t\t||*************||TIDAK ADA DATA||***************||");
			System.out.println("\t\t\t\t||**************||TERIMA KASIH||****************||");
			System.out.println("\t\t\t\t||*********||Press enter to continue||**********||");
			System.out.println("\t\t\t\t||==============================================||");
			scan.nextLine();
		}else{
			for(int i=0;i<pulsa.size();i++){
				System.out.printf("|| %2d || %10s | %22s | %18s | %18s | %12d | %14d ||\n", i+1,pulsa.get(i).getKodeTransaksi(), pulsa.get(i).getTanggalTransaksi(), pulsa.get(i).getNamaItem(),pulsa.get(i).getNomorHape(),pulsa.get(i).getSaldo(),pulsa.get(i).getHargaItem());
				System.out.println("=========================================================================================================================");
			}
			System.out.println("");
			System.out.println("Press enter to continue..");
			scan.nextLine();
		}
		enter();
	}
	
	private void checkoutBarang(){
		if(count==0 && barang.isEmpty()){
			table1();
			System.out.println("|| -  ||     -      |           -            |           -          |        -       |       -      |        -       ||");
			System.out.println("=======================================================================================================================");
			System.out.println("");
			System.out.println("\t\t\t\t||==============================================||");
			System.out.println("\t\t\t\t||*************||TIDAK ADA DATA||***************||");
			System.out.println("\t\t\t\t||**************||TERIMA KASIH||****************||");
			System.out.println("\t\t\t\t||*********||Press enter to continue||**********||");
			System.out.println("\t\t\t\t||==============================================||");
		}else if(barang.isEmpty()){
			table1();
			System.out.println("|| -  ||     -      |           -            |           -          |        -       |       -      |        -       ||");
			System.out.println("=======================================================================================================================");
			System.out.println("");
			System.out.println("\t\t\t\t||==============================================||");
			System.out.println("\t\t\t\t||*************||TIDAK ADA DATA||***************||");
			System.out.println("\t\t\t\t||**************||TERIMA KASIH||****************||");
			System.out.println("\t\t\t\t||*********||Press enter to continue||**********||");
			System.out.println("\t\t\t\t||==============================================||");
		}else if(count == 0) {
			do{
				enter();
				template();
				System.out.println("==============================================================================");
				System.out.print("Tolong Masukan Alamat Lengkap Anda [ 5 - 30 ] : ");
				alamat = scan.nextLine();
				if(alamat.length()<5||alamat.length()>30){
					enter();
					template();
					System.out.println("================================================================================");
					System.out.println("Mohon Untuk Memasukkan Alamat Lengkap Jumlah Huruf Antara 5 Sampai 30 !");
					System.out.println("================================================================================");
					System.out.println("Press Enter To Continue...");
					scan.nextLine();
				}
				barang.get(0).setAlamat(alamat);
			}while(alamat.length()<5||alamat.length()>30);
			System.out.println("==============================================================================");
			System.out.println("Press enter to continue..");
			scan.nextLine();
			enter();
			System.out.println("=======================================================================================================================");
			System.out.println("Alamat Lengkap : " + barang.get(0).getAlamat());
			System.out.println("=======================================================================================================================");
			
			table1();	
			for(int i=0; i<barang.size(); i++) {
				System.out.printf( "|| %2d || %10s | %22s | %20s | %14d | %12d | %14d ||\n", (i+1), barang.get(i).getKodeTransaksi(), barang.get(i).getTanggalTransaksi(), barang.get(i).getNamaItem(), barang.get(i).getQuantity(), barang.get(i).getHargaItem(), barang.get(i).getQuantity()* barang.get(i).getHargaItem());
				System.out.println("=======================================================================================================================");
			}
			System.out.println("");
			System.out.println("Press enter to continue..");
			count++;
		}else if(count > 0) {
			barang.get(0).setAlamat(alamat);
			System.out.println("=======================================================================================================================");
			System.out.println("Alamat Lengkap : " + barang.get(0).getAlamat());
			System.out.println("=======================================================================================================================");
			table1();
		
			for(int i=0; i<barang.size(); i++) {
				System.out.printf( "|| %2d || %10s | %22s | %20s | %14d | %12d | %14d ||\n", (i+1), barang.get(i).getKodeTransaksi(), barang.get(i).getTanggalTransaksi(), barang.get(i).getNamaItem(), barang.get(i).getQuantity(), barang.get(i).getHargaItem(), barang.get(i).getQuantity()* barang.get(i).getHargaItem());
				System.out.println("=======================================================================================================================");
			}
			System.out.println("");
			System.out.println("Press enter to continue..");
		}
		scan.nextLine();
		enter();
	}
	
	private void deletePulsa(){
		int pilih3 = 0;
		enter();
		
		if(pulsa.isEmpty()){
			table();
			System.out.println("||    ||     -      |           -            |          -         |          -         |       -      |        -       ||");
			System.out.println("=========================================================================================================================");
			System.out.println("");
			System.out.println("==================================");
			System.out.println("There is no data..");
			System.out.println("Press enter to continue..");
			System.out.println("==================================");
			scan.nextLine();
			enter();
		}else{
			do{
				enter();
				table();
				for(int i=0;i<pulsa.size();i++){
					System.out.printf("|| %2d || %10s | %22s | %18s | %18s | %12d | %14d ||\n", i+1,pulsa.get(i).getKodeTransaksi(), pulsa.get(i).getTanggalTransaksi(), pulsa.get(i).getNamaItem(),pulsa.get(i).getNomorHape(),pulsa.get(i).getSaldo(),pulsa.get(i).getHargaItem());
					System.out.println("=========================================================================================================================");
				}
				System.out.println("");
				System.out.println("==================================");
				System.out.println("|| What Do You Want :           ||");
				System.out.println("|| 1. Delete All                ||");
				System.out.println("|| 2. Delete One (Choose One)   ||");
				System.out.println("==================================");
				System.out.print("Choose : ");
				try{
					pilih3=scan.nextInt();
					scan.nextLine();
				}catch(Exception e){
					pilih3=-1;
					scan.nextLine();
				}
				
				if(pilih3!=1&&pilih3!=2){
					enter();
					template();
					System.out.println("==========================================================================");
					System.out.println("Mohon Pilih Menu Yang Diinginkan Atau Tersedia ( Nomor ) ! ");
					System.out.println("==========================================================================");
					System.out.println("Press Enter To Continue...");
					scan.nextLine();
					enter();
				}
				
			}while(pilih3!=1&&pilih3!=2);
			
			if(pilih3==1){
				pulsa.removeAllElements();
				System.out.println("==================================");
				System.out.println("Delete success...");
				System.out.println("Press enter to continue..");
				System.out.println("==================================");
				scan.nextLine();
			}else if(pilih3==2){	
				int angka=-1;
				do {
					enter();
					table();
					for(int i=0;i<pulsa.size();i++){
						System.out.printf("|| %2d || %10s | %22s | %18s | %18s | %12d | %14d ||\n", i+1,pulsa.get(i).getKodeTransaksi(), pulsa.get(i).getTanggalTransaksi(), pulsa.get(i).getNamaItem(),pulsa.get(i).getNomorHape(),pulsa.get(i).getSaldo(),pulsa.get(i).getHargaItem());
						System.out.println("=========================================================================================================================");
					}
					System.out.printf("Input Nomor Yang Ingin Didelete [1...%d | 0 to exit] : ",pulsa.size());
					try{
						angka = scan.nextInt();
						scan.nextLine();
					}catch(Exception e){
						angka=-1;
						scan.nextLine();
					}
					
					if(angka==0)break;  
					else if(angka<=pulsa.size()&& angka>0){
						pulsa.remove(angka-1);
						System.out.println("==================================");
						System.out.println("Delete success...");
						System.out.println("Press enter to continue..");
						System.out.println("==================================");
						scan.nextLine();
						break;	
					}
				}while(angka!=0 || angka> pulsa.size());
			}
			enter();			  	
		}	
	}
	
	private void deleteBarang(){
		int pilih4 = 0;
		enter();
		
		if(barang.isEmpty()){
			table1();
			System.out.println("|| -  ||     -      |           -            |           -          |        -       |       -      |        -       ||");
			System.out.println("=======================================================================================================================");
			System.out.println("");
			System.out.println("==================================");
			System.out.println("There is no data..");
			System.out.println("Press enter to continue..");
			System.out.println("==================================");
			scan.nextLine();
			enter();
		}else{
			do{
				enter();
				table1();
				for(int i=0;i<barang.size();i++){
					System.out.printf( "|| %2d || %10s | %22s | %20s | %14d | %12d | %14d ||\n", (i+1), barang.get(i).getKodeTransaksi(), barang.get(i).getTanggalTransaksi(), barang.get(i).getNamaItem(), barang.get(i).getQuantity(), barang.get(i).getHargaItem(), barang.get(i).getQuantity()* barang.get(i).getHargaItem());
					System.out.println("=======================================================================================================================");
				}
				System.out.println("");
				System.out.println("==================================");
				System.out.println("|| What Do You Want :           ||");
				System.out.println("|| 1. Delete All                ||");
				System.out.println("|| 2. Delete One (Choose One)   ||");
				System.out.println("==================================");
				System.out.print("Choose : ");
				try{
					pilih4=scan.nextInt();
					scan.nextLine();
				}catch(Exception e){
					pilih4=-1;
					scan.nextLine();
				}	
				
				if(pilih4!=1&&pilih4!=2){
					enter();
					template();
					System.out.println("==========================================================================");
					System.out.println("Mohon Pilih Menu Yang Diinginkan Atau Tersedia ( Nomor ) ! ");
					System.out.println("==========================================================================");
					System.out.println("Press Enter To Continue...");
					scan.nextLine();
					enter();
				}
				
			}while(pilih4!=1&&pilih4!=2);
			
			if(pilih4==1){
				barang.removeAllElements();
				System.out.println("==================================");
				System.out.println("Delete success...");
				System.out.println("Press enter to continue..");
				System.out.println("==================================");
				scan.nextLine();
			}else if(pilih4==2){	
				int angka1=-1;
				do {
					enter();
					table1();
					for(int i=0;i<barang.size();i++){
						System.out.printf( "|| %2d || %10s | %22s | %20s | %14d | %12d | %14d ||\n", (i+1), barang.get(i).getKodeTransaksi(), barang.get(i).getTanggalTransaksi(), barang.get(i).getNamaItem(), barang.get(i).getQuantity(), barang.get(i).getHargaItem(), barang.get(i).getQuantity()* barang.get(i).getHargaItem());
						System.out.println("=======================================================================================================================");
					}
					System.out.printf("Input Nomor Yang Ingin Didelete [1...%d | 0 to exit] : ",barang.size());
					try{
						angka1 = scan.nextInt();
						scan.nextLine();
					}catch(Exception e){
						angka1=-1;
						scan.nextLine();
					}
					
					if(angka1==0)break;  
					else if(angka1<=barang.size()&& angka1>0){
						barang.remove(angka1-1);
						System.out.println("==================================");
						System.out.println("Delete success...");
						System.out.println("Press enter to continue..");
						System.out.println("==================================");
						scan.nextLine();
						break;	
					}
				}while(angka1!=0 || angka1> barang.size());
			}
			enter();			  	
		}	
	}
	
	private void enter(){
		for(int i=0;i<100;i++){
			System.out.printf("\n");
		}
	}
	
	private void quit(){
		System.out.println("\t\t\t\t\t______________________________________________");
		System.out.println("\t\t\t\t\t||   Thank you for using this application!  ||");
		System.out.println("\t\t\t\t\t||************SEE YOU NEXT TIME*************||");
		System.out.println("\t\t\t\t\t||                   ****                   ||");
		System.out.println("\t\t\t\t\t||               ************               ||");
		System.out.println("\t\t\t\t\t||           ********************           ||");
		System.out.println("\t\t\t\t\t||       ********##********##********       ||");
		System.out.println("\t\t\t\t\t||     *********####******####*********     ||");
		System.out.println("\t\t\t\t\t||    ***********##********##***********    ||");
		System.out.println("\t\t\t\t\t||    **********************************    ||");
		System.out.println("\t\t\t\t\t||    **********************************    ||");
		System.out.println("\t\t\t\t\t||    **********************************    ||");
		System.out.println("\t\t\t\t\t||     *********#*************#********     ||");
		System.out.println("\t\t\t\t\t||       ********#***********#*******       ||");
		System.out.println("\t\t\t\t\t||          ******###########*****          ||");
		System.out.println("\t\t\t\t\t||             ******#####******            ||");
		System.out.println("\t\t\t\t\t||                 *********                ||");
		System.out.println("\t\t\t\t\t||                    **                    ||");
		System.out.println("\t\t\t\t\t||                                          ||");
		System.out.println("\t\t\t\t\t||                   LC 01                  ||");
		System.out.println("\t\t\t\t\t||__________________________________________||");
	}
	
	public Main() {
		Integer pilih=0;
		welcome();
		inputData();
		
		System.out.println("==============================================================================================");
		System.out.println("\t\t\t\t   DATA PEMBELI");
		System.out.println("==============================================================================================");
		System.out.println("Nama    : "+namaPembeli);
		System.out.println("Email   : "+email);
		System.out.println("Password: "+pass);
		System.out.println("==============================================================================================");
		System.out.println("");
		do{
			template();
			System.out.println("");
			System.out.println("========================");
			System.out.println("|----Bukapedia Mall----|");
			System.out.println("========================");
			System.out.println("|| 1. Beli Pulsa      ||");
			System.out.println("|| 2. Beli Barang     ||");
			System.out.println("|| 3. Exit            ||");
			System.out.println("||____________________||");
			
			try{
				System.out.print("Choose : ");
				pilih=scan.nextInt();
				scan.nextLine();
			}catch(Exception e){
				pilih=-1;
				scan.nextLine();
				enter();
			}
			
			if(pilih!=1&&pilih!=2&&pilih!=3){
				enter();
				template();
				System.out.println("==========================================================================");
				System.out.println("Mohon Pilih Menu Yang Diinginkan Atau Tersedia ( Nomor ) ! ");
				System.out.println("==========================================================================");
				System.out.println("Press Enter To Continue...");
				scan.nextLine();
				enter();
			}
			
			enter();
				
			switch(pilih){
			case 1:
				enter();
				Integer pilih1=0;
				do{
					enter();
					template();
					System.out.println("");
					System.out.println("============================================");
					System.out.println("|------------------Pulsa-------------------|");
					System.out.println("||========================================||");
					System.out.println("|| 1. Add Item                            ||");
					System.out.println("|| 2. Lihat keranjang (sort by harga)     ||");
					System.out.println("|| 3. Lihat keranjang (sort by nama item) ||");
					System.out.println("|| 4. Batalkan Pesanan                    ||");
					System.out.println("|| 5. Checkout                            ||");
					System.out.println("||========================================||");
					
					try{
						System.out.print("Choose : ");
						pilih1=scan.nextInt();
						scan.nextLine();
					}catch(Exception e){
						pilih1=-1;
						scan.nextLine();
						enter();
					}
					
					if(pilih1!=1&&pilih1!=2&&pilih1!=3&&pilih1!=4&&pilih1!=5){
						enter();
						template();
						System.out.println("==========================================================================");
						System.out.println("Mohon Pilih Menu Yang Diinginkan Atau Tersedia ( Nomor ) ! ");
						System.out.println("==========================================================================");
						System.out.println("Press Enter To Continue...");
						scan.nextLine();
						enter();
					}
					
					enter();
						
					switch(pilih1){
					case 1:
						enter();
						inputPulsa();
						break;
					case 2:
						enter();
						sortHargaPulsa();
						break;
					case 3:
						enter();
						sortOperatorPulsa();
						break;
					case 4:
						enter();
						deletePulsa();
						break;
					case 5:
						enter();
						checkoutPulsa();
						pilih=-1;
						break;
					}
				}while(pilih1!=5);
			
				break;
			case 2:
				enter();
				Integer pilih2=0;
				do{
					enter();
					template();
					System.out.println("");
					System.out.println("============================================");
					System.out.println("|------------------Barang------------------|");
					System.out.println("||========================================||");
					System.out.println("|| 1. Add Item                            ||");
					System.out.println("|| 2. Lihat keranjang (sort by harga)     ||");
					System.out.println("|| 3. Lihat keranjang (sort by nama item) ||");
					System.out.println("|| 4. Batalkan Pesanan                    ||");
					System.out.println("|| 5. Checkout                            ||");
					System.out.println("||========================================||");
					
					try{
						System.out.print("Choose : ");
						pilih2=scan.nextInt();
						scan.nextLine();
					}catch(Exception e){
						pilih2=-1;
						scan.nextLine();
						enter();
					}
					
					if(pilih2!=1&&pilih2!=2&&pilih2!=3&&pilih2!=4&&pilih2!=5){
						enter();
						template();
						System.out.println("==========================================================================");
						System.out.println("Mohon Pilih Menu Yang Diinginkan Atau Tersedia ( Nomor ) ! ");
						System.out.println("==========================================================================");
						System.out.println("Press Enter To Continue...");
						scan.nextLine();
						enter();
					}
					
					enter();
						
					switch(pilih2){
					case 1:
						inputBarang();
						enter();
						break;
					case 2:
						enter();
						sortHargaBarang();
						break;
					case 3:
						enter();
						sortNamaBarang();
						break;
					case 4:
						enter();
						deleteBarang();
						break;
					case 5:
						enter();
						checkoutBarang();
						pilih=-1;
						break;
					}
				}while(pilih2!=5);
				break;
			case 3:
				enter();
				quit();
				return;
			}
		}while(pilih!=3);
	}

	public static void main(String[] args) {
		new Main();

	}

}

//Sumber:
//https://www.tutorialspoint.com/java/java_regular_expressions.htm //
//https://stackoverflow.com/questions/16425127/how-to-use-collections-sort-in-java