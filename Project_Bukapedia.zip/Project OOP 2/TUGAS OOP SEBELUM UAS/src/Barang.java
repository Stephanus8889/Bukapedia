
public class Barang extends Bukapediamall{
	private Integer quantity;
	private String alamat;
	
	public Barang(String namaPembeli, String namaItem, Integer hargaItem, String tanggalTransaksi,
			String kodeTransaksi, Integer quantity, String alamat) {
		super(namaPembeli, namaItem, hargaItem, tanggalTransaksi, kodeTransaksi);
		this.quantity = quantity;
		this.alamat = alamat;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public String getAlamat() {
		return alamat;
	}

	public void setAlamat(String alamat) {
		this.alamat = alamat;
	}
	
	public int listHarga() {
		return quantity*this.getHargaItem();
	}
	
	
	
	

}
