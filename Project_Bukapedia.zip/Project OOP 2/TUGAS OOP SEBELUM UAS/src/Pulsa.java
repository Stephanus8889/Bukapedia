
public class Pulsa extends Bukapediamall{
	private String nomorHape;
	private Integer saldo;
	
	public Pulsa(String namaPembeli, String namaItem, Integer hargaItem, String tanggalTransaksi, String kodeTransaksi,
			String nomorHape, Integer saldo) {
		super(namaPembeli, namaItem, hargaItem, tanggalTransaksi, kodeTransaksi);
		this.nomorHape = nomorHape;
		this.saldo = saldo;
	}

	public String getNomorHape() {
		return nomorHape;
	}

	public void setNomorHape(String nomorHape) {
		this.nomorHape = nomorHape;
	}

	public Integer getSaldo() {
		return saldo;
	}

	public void setSaldo(Integer saldo) {
		this.saldo = saldo;
	}

	public int listHarga() {
		return saldo + saldo*10/100;
		
	}
	
	

}
