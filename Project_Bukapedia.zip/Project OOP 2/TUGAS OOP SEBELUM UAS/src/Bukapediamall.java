
public abstract class Bukapediamall {
	private String namaPembeli;
	private String namaItem;
	private Integer hargaItem;
	private String tanggalTransaksi;
	private String kodeTransaksi;	
	
	public Bukapediamall(String namaPembeli, String namaItem, Integer hargaItem, String tanggalTransaksi,
			String kodeTransaksi) {
		super();
		this.namaPembeli = namaPembeli;
		this.namaItem = namaItem;
		this.hargaItem = hargaItem;
		this.tanggalTransaksi = tanggalTransaksi;
		this.kodeTransaksi = kodeTransaksi;
	}

	public String getNamaPembeli() {
		return namaPembeli;
	}

	public void setNamaPembeli(String namaPembeli) {
		this.namaPembeli = namaPembeli;
	}

	public String getNamaItem() {
		return namaItem;
	}

	public void setNamaItem(String namaItem) {
		this.namaItem = namaItem;
	}

	public Integer getHargaItem() {
		return hargaItem;
	}

	public void setHargaItem(Integer hargaItem) {
		this.hargaItem = hargaItem;
	}

	public String getTanggalTransaksi() {
		return tanggalTransaksi;
	}

	public void setTanggalTransaksi(String tanggalTransaksi) {
		this.tanggalTransaksi = tanggalTransaksi;
	}

	public String getKodeTransaksi() {
		return kodeTransaksi;
	}

	public void setKodeTransaksi(String kodeTransaksi) {
		this.kodeTransaksi = kodeTransaksi;
	}
	
	public abstract int listHarga();

}
