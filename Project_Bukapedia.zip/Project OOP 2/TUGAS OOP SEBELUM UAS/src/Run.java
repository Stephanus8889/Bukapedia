import java.util.Random;

public class Run implements Runnable{

	Random rand = new Random();
	
	private int i = 0;
	private int a = 0;
	private void enter(){
		for(int i=0;i<100;i++){
			System.out.printf("\n");
		}
	}

	public void run() {
		System.out.println("Loading 0%");
		while(a <= 100){
			try {
				i = rand.nextInt(100)+1;
				Thread.sleep(1000);
				a += i;
				if(a >= 100){
					a = 100;
					break;
				}
				enter();
				System.out.println("==========================================================================");
				System.out.printf("Loading %d%%\n", a);
				System.out.println("==========================================================================");
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		enter();
		System.out.println("==========================================================================");
		System.out.printf("Loading %d%%\n", a);
		System.out.println("==========================================================================");
		System.out.println("");
		System.out.println("Press enter to continue..");
		
	}
}
